package bankmanagement;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public  class SignupTwo extends JFrame implements ActionListener {
    
    JTextField t4,t5;
    JButton next;
    JRadioButton m,f,M,U;
    JComboBox religion,category,income,education,occupation;
    String f1;
    
    SignupTwo(String f1){
        this.f1=f1;
        setLayout(null);
        setTitle("NEW APPLICATION FORM - PAGE 2");
     
     JLabel f2=new JLabel("      PAGE  2 :    ADDITIONAL DETAILS  ");
     f2.setFont(new Font("Calibri",Font.BOLD,22));
     f2.setBounds(250,80,400,30);
     add(f2); 
     
     JLabel f3=new JLabel("Religion:");
     f3.setFont(new Font("Serif",Font.BOLD,20));
     f3.setBounds(100,140,80,30);
     add(f3);
     String valReligion[] = {"Hindu", "Muslim ","Sikh","Cristian","Others"};
      religion =  new JComboBox(valReligion);
      religion.setBounds(300,140,400,30);
     add(religion);
     
     
     JLabel f4=new JLabel("Category :");
     f4.setFont(new Font("Serif",Font.BOLD,20));
     f4.setBounds(100,190,200,30);
     add(f4);
     String valctegory[]={"General","SC","ST","OBC","Others"};
      category =new JComboBox(valctegory);
     category.setBounds(300,190,400,30);
     add(category);
     
     JLabel f5=new JLabel("Income :");
     f5.setFont(new Font("Serif",Font.BOLD,20));
     f5.setBounds(100,240,300,30);
     add(f5);
     String incomectegory[]={"Null","<1,50,000","<2,50,000","<5,00,000","Up to 10,00,000"};
      income =new JComboBox(incomectegory);
     income.setBounds(300,240,400,30);
     add(income);

    JLabel f6=new JLabel("Educational");
     f6.setFont(new Font("Serif",Font.BOLD,20));
     f6.setBounds(100,310,200,30);
     add(f6);
     JLabel f7=new JLabel("Qualification :");
     f7.setFont(new Font("Serif",Font.BOLD,20));
     f7.setBounds(100,330,300,30);
     add(f7);
     String educationalValues[]={"10th","12th","Non Graduate","Graduate","Post-Graduate"};
      education =new JComboBox(educationalValues);
     education.setBounds(300,325,400,30);
     add(education);
    
     
     JLabel f8=new JLabel("Occupation :");
     f8.setFont(new Font("Serif",Font.BOLD,20));
     f8.setBounds(100,390,300,30);
     add(f8);
      String occupationValues[]={"salaried","Self employed","Buissnes","Student","Retired","Otehrs"};
      occupation =new JComboBox(occupationValues);
     occupation.setBounds(300,390,400,30);
     add(occupation);
   
     
     
     JLabel f9=new JLabel("Pan No. :");
     f9.setFont(new Font("Serif",Font.BOLD,20));
     f9.setBounds(100,440,300,30);
     add(f9);
     t4=new JTextField();
     t4.setFont(new Font("Arial",Font.BOLD,14));
     t4.setBounds(300,440,400,30);
     add(t4);
     
      JLabel f10=new JLabel("Adhar No. :");
     f10.setFont(new Font("Serif",Font.BOLD,20));
     f10.setBounds(100,490,300,30);
     add(f10);
     t5=new JTextField();
     t5.setFont(new Font("Arial",Font.BOLD,14));
     t5.setBounds(300,490,400,30);
     add(t5);
     
     JLabel f11=new JLabel("Senior Citizen :");
     f11.setFont(new Font("Serif",Font.BOLD,20));
     f11.setBounds(100,540,300,30);
     add(f11);
      M=new JRadioButton("Yes");
     M.setBounds(300,540,100,30);
     M.setBackground(Color.WHITE);
     add(M);
     
     U=new JRadioButton("No");
     U.setBounds(440,540,100,30);
     U.setBackground(Color.WHITE);
     add(U);
     ButtonGroup G= new ButtonGroup();
    G.add(M);
    G.add(U);
    
     
     JLabel f12=new JLabel("Existing Account:");
     f12.setFont(new Font("Serif",Font.BOLD,20));
     f12.setBounds(100,590,300,30);
     add(f12);
       m=new JRadioButton("Yes");
     m.setBounds(300,590,100,30);
     m.setBackground(Color.WHITE);
     add(m);
     
     f=new JRadioButton("No");
     f.setBounds(440,590,100,30);
     f.setBackground(Color.WHITE);
     add(f);
     ButtonGroup a= new ButtonGroup();
    a.add(m);
    a.add(f);
   
     
     next=new JButton("NEXT");
     next.setBackground(Color.BLACK);
     next.setForeground(Color.WHITE);
     next.setFont(new Font("Raleway",Font.BOLD,14));
     next.setBounds(620,660,80,30);
     next.addActionListener(this);
     add(next);
     
    
     
        getContentPane().setBackground(Color.CYAN);
        
        setSize(900,800);
        setLocation(350,10);
        setVisible(true);
    }
    public void actionPerformed(ActionEvent ae){
        if (ae.getSource()== next){
            setVisible(false);
            new SignupThree(f1).setVisible(true);
        }
        String f3= (String)religion.getSelectedItem();
        String f4=(String)category.getSelectedItem();
        String f5=(String)income.getSelectedItem();
        String f7=(String)education.getSelectedItem();
        String f8=(String)occupation.getSelectedItem();
        String f11=null;
        if(M.isSelected()){
            f11="Yes";
        }else if(U.isSelected()){
            f11="No";
        }
        String f12=null;
        if(m.isSelected() ){
            f12="Yes";
        }else if(f.isSelected()){
            f12="No";
        }
        String f9=t4.getText();
        String f10=t5.getText();
        
        try{
                Conn c =new Conn();
                String query="insert into signup_two values('"+f1+"','"+f3+"','"+f4+"','"+f5+"','"+f7+"','"+f8+"','"+f9+"','"+f10+"','"+f11+"','"+f12+"')";
                c.s.executeUpdate(query);
        }catch(Exception e){
            System.out.println(e);
            setVisible(false);
            new SignupThree(f1).setVisible(true);
        }
    }
    public static void main(String args[]){
        new SignupTwo("");
        
    }

    }
