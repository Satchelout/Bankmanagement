
package bankmanagement;
import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.awt.event.*;

public class MiniStatement extends JFrame implements ActionListener  {
        JButton ok;
        MiniStatement(String pinnumber){
            setTitle("Mini Statement");
            setLayout(null);
           
           JLabel mini=new JLabel();//for printing values dynamicaly
           add (mini);
           
           JLabel bank=new JLabel("IDBI BANK");
           bank.setBounds(150, 20, 100, 20);
           bank.setFont(new Font("Arial",Font.BOLD,16));
           add (bank);
           
           ok= new JButton("OK");
           ok.setBounds(150,480,100,30);
           ok.addActionListener(this);
           add(ok);
                   
           JLabel card=new JLabel();
           card.setBounds(20,80,300,20);
           add (card);
           
           
           JLabel balance = new JLabel();
           balance.setBounds(20, 400, 320, 20);
           
           try {
               Conn c = new Conn();
              ResultSet rs = c.s.executeQuery("select * from login where pin = '"+pinnumber+"'");
              while(rs.next()) {
                  card.setText("Caed Number :" + rs.getString("cardnumber").substring(0, 4) + "XXXXXXXX" + rs.getString("cardnumber").substring(12));
              }
           }catch(Exception e) {
               System.out.println(e);
           }
           try {
               Conn c= new Conn();
               int bal = 0;
               ResultSet rs=c.s.executeQuery("select * from bank where pin = '"+pinnumber+"'");
               while(rs.next()) {
                  mini.setText(mini.getText()+ "<html>" + rs.getString("date") + "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;" +rs.getString("type") +"&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;"  +rs.getString("amount")+ "<br><br><html>"); 
                if (rs.getString("type").equals("Deposit")) {
                        bal +=Integer.parseInt(rs.getString("amount"));
                    }else {
                        bal -=Integer.parseInt(rs.getString("amount"));
                    }
               }
               balance.setText("Your Current account Balnace is Rs :" +bal);
           }catch (Exception e){
               System.out.println(e);
           }
            
           mini.setBounds(20, 140, 400, 200);
           
            setSize(400,600);
            setLocation(20,20);
            getContentPane().setBackground(Color.WHITE);
            setVisible(true);
        }
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource()== ok){
            setVisible(false);
        }
    }
    public static void main(String args[]) {
        new MiniStatement("").setVisible(true);
    }
}
