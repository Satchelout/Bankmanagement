package bankmanagement;

import javax.swing.*;
import java.awt.*;
import java.util.*;
import com.toedter.calendar.JDateChooser;
import java.awt.event.*;

public  class SignupOne extends JFrame implements ActionListener {
    
    long random;
    JTextField p,t1,t2,t3,t4,t5,t6,t7;
    JButton next;
    JRadioButton m,f,o,M,U;
    JDateChooser datechooser;
    SignupOne(){
        setLayout(null);
     Random ran = new Random();
     random =Math.abs((ran.nextLong() % 9000L) + 1000L);

     JLabel f1=new JLabel("APPLICATION FORM NO:"+random);   
        f1.setFont(new Font("Serif",Font.BOLD,35));
        f1.setBounds(200,20,600,40);
        add(f1);
        p =new JTextField("       PICTURE  ");
        p.setBounds(750,20,100,100);
        add(p);
     JLabel f2=new JLabel("      PAGE1 :    PERSONAL DETAILS  ");
     f2.setFont(new Font("Calibri",Font.BOLD,22));
     f2.setBounds(250,80,400,30);
     add(f2); 
     
     JLabel f3=new JLabel("NAME :");
     f3.setFont(new Font("Serif",Font.BOLD,20));
     f3.setBounds(100,140,100,30);
     add(f3);
     t1=new JTextField();
     t1.setFont(new Font("Arial",Font.BOLD,14));
     t1.setBounds(300,140,400,30);
     add(t1);
     
     JLabel f4=new JLabel("FATHER'S NAME :");
     f4.setFont(new Font("Serif",Font.BOLD,20));
     f4.setBounds(100,190,200,30);
     add(f4);
     t2=new JTextField();
     t2.setFont(new Font("Arial",Font.BOLD,14));
     t2.setBounds(300,190,400,30);
     add(t2);
     
     JLabel f5=new JLabel("DATE OF BIRTH :");
     f5.setFont(new Font("Serif",Font.BOLD,20));
     f5.setBounds(100,240,300,30);
     add(f5);
     datechooser=new JDateChooser();
     datechooser.setBounds(300,240,200,30);
     datechooser.setForeground(Color.red);
     datechooser.setFont(new Font("Serif",Font.BOLD,18));
     add(datechooser);
     
    JLabel f6=new JLabel("GENDER :");
     f6.setFont(new Font("Serif",Font.BOLD,20));
     f6.setBounds(100,290,300,30);
     add(f6);
     m=new JRadioButton("MALE"); 
     m.setBounds(300,290,60,30);
     m.setBackground(Color.WHITE);
     add(m);
     f=new JRadioButton("FEMALE");
     f.setBounds(450,290,120,30);
     f.setBackground(Color.WHITE);
     add(f);
     o=new JRadioButton("OTHERS");
     o.setBounds(600,290,160,30);
     o.setBackground(Color.WHITE);
     add(o);
     //ButtonGroup will alow us to select one radiobutton at a time bye creat new obj

    ButtonGroup g=new ButtonGroup();
    g.add(m);
    g.add(f);
    g.add(o);
     
     JLabel f7=new JLabel("EMAIL ADDRESS :");
     f7.setFont(new Font("Serif",Font.BOLD,20));
     f7.setBounds(100,340,300,30);
     add(f7);
     t3=new JTextField();
     t3.setFont(new Font("Arial",Font.BOLD,14));
     t3.setBounds(300,340,400,30);
     add(t3);
     
      JLabel f8=new JLabel("MARITAl STATUS :");
     f8.setFont(new Font("Serif",Font.BOLD,20));
     f8.setBounds(100,390,300,30);
     add(f8);
     M=new JRadioButton("MARRIED");
     M.setBounds(300,390,100,30);
     M.setBackground(Color.WHITE);
     add(M);
     
     U=new JRadioButton("UNMERRIED");
     U.setBounds(440,390,100,30);
     U.setBackground(Color.WHITE);
     add(U);
     //ButtonGroup will alow us to select one radiobutton at a time bye creat new obj
     ButtonGroup G= new ButtonGroup();
    G.add(M);
    G.add(U);
     
     
     JLabel f9=new JLabel("ADDRESS :");
     f9.setFont(new Font("Serif",Font.BOLD,20));
     f9.setBounds(100,440,300,30);
     add(f9);
     t4=new JTextField();
     t4.setFont(new Font("Arial",Font.BOLD,14));
     t4.setBounds(300,440,400,30);
     add(t4);
     
      JLabel f10=new JLabel("CITY :");
     f10.setFont(new Font("Serif",Font.BOLD,20));
     f10.setBounds(100,490,300,30);
     add(f10);
     t5=new JTextField();
     t5.setFont(new Font("Arial",Font.BOLD,14));
     t5.setBounds(300,490,400,30);
     add(t5);
     
     JLabel f11=new JLabel("STATE :");
     f11.setFont(new Font("Serif",Font.BOLD,20));
     f11.setBounds(100,540,300,30);
     add(f11);
     t6=new JTextField();
     t6.setFont(new Font("Arial",Font.BOLD,14));
     t6.setBounds(300,540,400,30);
     add(t6);
     
     JLabel f12=new JLabel("PIN CODE :");
     f12.setFont(new Font("Serif",Font.BOLD,20));
     f12.setBounds(100,590,300,30);
     add(f12);
     t7=new JTextField();
     t7.setFont(new Font("Arial",Font.BOLD,14));
     t7.setBounds(300,590,400,30);
     add(t7);
     //by adding actionlistner to next buuton it will work when we will click on next button//
     next=new JButton("NEXT");
     next.setBackground(Color.BLACK);
     next.setForeground(Color.WHITE);
     next.setFont(new Font("Raleway",Font.BOLD,14));
     next.setBounds(620,660,80,30);
     next.addActionListener(this);
     add(next);
     
    
     
        getContentPane().setBackground(Color.CYAN);
        
        setSize(900,800);
        setLocation(350,10);
        setVisible(true);
    }
    public void actionPerformed(ActionEvent ae){
        String f1= "" + random;
        String f3= t1.getText();//gettext will collect the data from textfield
        String f4=t2.getText();
        String f5=((JTextField) datechooser.getDateEditor().getUiComponent()).getText();
        String f6=null;
        if(m.isSelected()){
            f6="Male";
        }else if(f.isSelected()){
            f6="Female";
        }else if (o.isSelected()){
            f6="Other";
        }
        String f7=t3.getText();
        String f8=null;
        if(M.isSelected() ){
            f8="Married";
        }else if(U.isSelected()){
            f8="Unmerried";
        }
        String f9=t4.getText();
        String f10=t5.getText();
        String f11=t6.getText();
        String f12=t7.getText();

        
        try{
            if(f3.equals("")){
                JOptionPane.showMessageDialog(null,"Name is required");
            }else {
                Conn c =new Conn();
                String query="insert into sign_up values('"+f1+"','"+f3+"','"+f4+"','"+f5+"','"+f6+"','"+f7+"','"+f8+"','"+f9+"','"+f10+"','"+f11+"','"+f12+"')";
                c.s.executeUpdate(query);
                setVisible(false);
                new SignupTwo(f1).setVisible(true);
            }
        }catch(Exception e){
            System.out.println(e);
        }
    }
    public static void main(String args[]){
        new SignupOne();
        
    }

    }

