package bankmanagement;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;

//implementing frame by extending and adding actionlistner for workinng of buuton
public class Login extends JFrame implements ActionListener{
    
    JButton b1,b3,b2; 
    JTextField t1;
    JPasswordField t2;
    
    Login() {
        
        //settingup title in frame
        setTitle("BANK MANAGEMENT SYSTEM");
        setLayout(null);
        //Imageicon for set image on frame
        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icons/logo.jpg"));
        Image i2=i1.getImage().getScaledInstance(100, 100,Image.SCALE_DEFAULT );
        ImageIcon i3=new ImageIcon(i2);
        JLabel label= new JLabel(i3);
        label.setBounds(70,20, 100,100);
  
        add(label);
        getContentPane().setBackground(Color.BLUE);
        //Adding labels 
        //SetBounds will setup in frame accoring to given axis
        JLabel t= new JLabel ("WELCOME TO ATM");
        t.setFont(new Font("Osward",Font.BOLD,38));
        t.setBounds(200,30, 400 ,50);
        add(t);
        
        JLabel Cardno= new JLabel ("Card number :");
        Cardno.setFont(new Font("Osward",Font.BOLD,26));
        Cardno.setBounds(200,120, 300 ,50);
        add(Cardno);
        
        JLabel pin= new JLabel ("Pin :");
        pin.setFont(new Font("Osward",Font.BOLD,26));
        pin.setBounds(200,180, 200 ,30);
        add(pin);
       
        t1=new JTextField();
        t1.setBounds(400, 130, 200, 30);
        t1.setFont(new Font("Arial",Font.BOLD,20));
        add(t1);
        
        t2=new JPasswordField();
        t2.setBounds(400, 190, 200, 30);
        t2.setFont(new Font("Arial",Font.BOLD,30));

        add(t2);
        //creating 3buttons for sign in,sign up,and clear
        b1=new JButton("SIGN IN");
        b1.setBounds(300,300,100,40);
        b1.addActionListener(this);
        add(b1);
        
        b3=new JButton("CLEAR ");
        b3.setBounds(450,300,100,40);
        b3.addActionListener(this);
        add(b3);
        
        b2=new JButton("SIGN UP");
        b2.setBounds(320,350,200,40);
        b2.addActionListener(this);
        add(b2);
        //setting frame and frame size of 800 and 480
        setSize(800, 480);
        setVisible(true);
        setLocation(350,200);
    }
    public void actionPerformed(ActionEvent ae){
        
        if (ae.getSource()== b3){
            t1.setText("");
            t2.setText("");
         
        }else if(ae.getSource() == b1) {
           Conn c =new Conn(); 
           String cardnumber =t1.getText();
           String pinnumber =t2.getText();
           String query = "select * from login where cardnumber = '"+cardnumber+"' and pin ='"+pinnumber+"'";
           try{
               ResultSet rs = c.s.executeQuery(query);
               if(rs.next()){
                   setVisible(false);
                   new Transactions(pinnumber).setVisible(true);
               }else{
                   JOptionPane.showMessageDialog(null,"Incorrect card number or pin ");
               }
           }catch (Exception e){
               System.out.println(e);
           }
        }else if(ae.getSource()==b2){
            setVisible(false);
            new SignupOne().setVisible(true);
            
        }
        
    }
    public static void main(String args[]) {
        new Login();
    }
}